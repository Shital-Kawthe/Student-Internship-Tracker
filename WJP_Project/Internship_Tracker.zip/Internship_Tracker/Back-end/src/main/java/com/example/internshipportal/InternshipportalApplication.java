package com.example.internshipportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternshipportalApplication {

	public static void main(String[] args) {
		SpringApplication.run(InternshipportalApplication.class, args);
	}

}
