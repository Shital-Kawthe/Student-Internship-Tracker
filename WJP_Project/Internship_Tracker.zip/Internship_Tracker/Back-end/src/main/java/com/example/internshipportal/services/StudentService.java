package com.example.internshipportal.services;

public class StudentService {

}
