package com.example.internshipportal.config;

public class SecurityConfig {

}
